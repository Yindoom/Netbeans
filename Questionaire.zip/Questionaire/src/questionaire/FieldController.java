/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionaire;
import javafx.scene.control.Label;

/**
 *
 * @author Yindo
 */
public class FieldController {
    private int X;
    private int Y;
    private String value;
    private Label label; 
    
    public FieldController (int xArg, int yArg, String valueArg) {
        this.X = xArg;
        this.Y = yArg;
        this.value = valueArg;
    }
    
    public void create (){
        this.label    = new Label(this.value);
        this.label.setTranslateX(this.X);
        this.label.setTranslateY(this.Y);
        
    }
}
