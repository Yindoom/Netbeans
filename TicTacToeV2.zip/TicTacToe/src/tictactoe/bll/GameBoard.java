/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe.bll;



/**
 *
 * @author Stegger
 */
public class GameBoard implements IGameModel
{
    int nextPlayer = 2;
    private Integer[][] board = new Integer[3][3];
        
    /**
     * Returns 0 for player 0, 1 for player 1.
     *
     * @return int Id of the next player.
     */
    
    public int getNextPlayer()
    {
        
        if(nextPlayer == 1)
        {
           nextPlayer = 2;
        }
        else
        {
            nextPlayer = 1;
        }
        return nextPlayer;
        
    }
    public int returnNextPlayer()
    {
        return nextPlayer;
    }
    /**
     * Attempts to let the current player play at the given coordinates. It the
     * attempt is succesfull the current player has ended his turn and it is the
     * next players turn.
     *
     * @param col column to place a marker in.
     * @param row row to place a marker in.
     * @return true if the move is accepted, otherwise false. If gameOver == true
     * this method will always return false.
     */
    public boolean play(int col, int row)
    {
        if(board[row][col] != null)
        {
        return false;
        }    
        else
            if(nextPlayer == 2)
            {
                board[row][col] = 1;
            }
            else
            {
                board[row][col] = 2;
            }
        {
        return true;
        }
    }
    int winner = -1;
    @Override
    public boolean isGameOver()
    {
        if(winner == -1)
            return false;
        else
            return true;
    }
    
    

    /**
     * Gets the id of the winner, -1 if its a draw.
     *
     * @return int id of winner, or -1 if draw.
     */
    public int getWinner()
    {
        
        for(int i = 0; i < 3; i++)  {
            if(board[i][0] != null && board[i][1] == board[i][0] && board[i][2] == board[i][0])
            {
                winner = board[i][0];
            }
            if(board[0][i] != null && board[1][i] == board[0][i] && board[2][i] == board[0][i])
            {
                winner = board[0][i];
            }
            if(board[1][1] != null && board[0][0] == board[1][1] && board[2][2] == board[1][1])
            {
                winner = board[1][1];
            }
            if(board[1][1] != null && board[0][2] == board[1][1] && board[2][0] == board[1][1])
            {
                winner = board[1][1];
            }
            else if(board[0][0] != null && board[1][0] != null && board[1][1] != null && board[0][1] != null)
            {
                winner = board[i][i];
            }
 
    }
        return winner;
    }

    /**
     * Resets the game to a new game state.
     */
    public void newGame()
    {
        nextPlayer = 1;
        //TODO Implement this method
    }

}
